﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the size");
            int n = Convert.ToInt32(Console.ReadLine());

            int[,] array1 = new int[n, n];

            int[,] array2 = new int[n, n];
            Console.WriteLine("enter the array one elements ");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    array1[i, j] = Convert.ToInt32(Console.ReadLine());
                }
                //Console.WriteLine();
            }
            Console.WriteLine("enter the array two elements");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    array2[i, j] = Convert.ToInt32(Console.ReadLine());
                }
                //Console.WriteLine();
            }
            bool flag = true;
            int choice = 0;
            while (flag)
            {
                Console.WriteLine();
                Console.WriteLine("1. switch of the elements except diagonal");
                Console.WriteLine("2.Get all the left diagonsal elements to a 1D array");
                Console.WriteLine("3. Square and add  all left diagonals element using while loop");
                Console.WriteLine("4.Swaping rows in a given matrix like 1 with nth row");
                Console.WriteLine("5.swaping rows and colms of two matrix");
                Console.WriteLine("6.Insertion sort of Diagonal elements");
                Console.WriteLine("7.linera search");
                Console.WriteLine("8.Binary search");
                Console.WriteLine("9.exit");
                Console.WriteLine("enter your choice");

                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        switchElements(array1, array2, n);



                        break;

                    case 2:
                        int[] temp = getLeftDiagonal(n, array1, array2);
                        for (int i = 0; i < n + n; i++)
                        {

                            Console.Write(temp[i] + " ");

                        }
                        break;

                    case 3:
                        int temp2 = squareAndAdd(n, array1, array2);
                        Console.WriteLine(temp2);

                        break;

                    case 4:
                        SwapingRows(n, array1);


                        break;
                    case 5:
                        SwapingRowsAndCol(n, array1, array2);
                        break;
                    case 6:
                        int[] temp1 = getLeftDiagonal(n, array1, array2);
                        int[] te = InsertionSort(temp1);
                        for (int i = 0; i < n + n; i++)
                        {

                            Console.Write(te[i] + " ");

                        }
                        break;

                    case 7:

                        Console.WriteLine("enter the element to search");
                        int x = Convert.ToInt32(Console.ReadLine());
                        int[] t = getLeftDiagonal(n, array1, array2);

                        int t1 = linearSearch(t, x);


                        break;
                    case 8:

                        Console.WriteLine("enter the key to be searched");
                        int key = Convert.ToInt32(Console.ReadLine());
                        int[] tem = getLeftDiagonal(n, array1, array2);
                        int[] Bina = InsertionSort(tem);


                        int xx = BinarySearchDisplay(Bina, key);
                        if (xx > 0)
                        {
                            Console.WriteLine("Element is found at index: " + xx);
                        }
                        else
                            Console.WriteLine("not found");
                        //Console.WriteLine(k);
                        ; break;
                    case 9:
                        Console.WriteLine("exit");
                        break;
                    default:

                        Console.WriteLine("invalid input");
                        flag = false;
                        break;



                }

            }
            Console.ReadKey();

        }





        public static int BinarySearchDisplay(int[] temp, int key)
        {
            //Console.WriteLine("binary");
            int low = 0;
            int high = temp.Length - 1;
            //int a = 0; 

            while (low <= high)
            {
                int mid = (low + high) / 2;
                if (key == temp[mid])
                {
                    //Console.WriteLine("Element is found at index: " + mid);
                    //a = mid;
                    return mid;

                }
                else if (key < temp[mid])
                {
                    high = mid - 1;
                }
                else
                {
                    low = mid + 1;
                }
            }
            return -1;

        }
        public static int linearSearch(int[] t, int x)
        {

            for (int i = 0; i < t.Length; i++)
            {
                if (t[i] == x)
                {
                    Console.WriteLine("element found at {0}", i);
                    return i;
                }
            }
            Console.WriteLine("element not found");
            return 1;
        }
        public static int[] InsertionSort(int[] arr)
        {
            int n = arr.Length;
            for (int i = 1; i < n; ++i)
            {
                int key = arr[i];
                int j = i - 1;
                while (j >= 0 && arr[j] > key)
                {
                    arr[j + 1] = arr[j];
                    j = j - 1;
                }
                arr[j + 1] = key;
            }
            return arr;
        }
        public static void SwapingRowsAndCol(int n, int[,] array1, int[,] array2)
        {
            int temp = 0;
            for (int i = 0; i < n; i++)
            {
                //for (int j = 0; j < n; j++)
                //{

                temp = array1[0, i];
                array1[0, i] = array2[i, 0];
                array2[i, 0] = temp;



                //}
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(array1[i, j] + " ");
                }
                Console.WriteLine();
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(array2[i, j] + " ");
                }
                Console.WriteLine();
            }

        }

        public static void SwapingRows(int n, int[,] array1)
        {
            int temp = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {

                    temp = array1[0, j];
                    array1[0, j] = array1[n - 1, j];
                    array1[n - 1, j] = temp;



                }
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(array1[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
        public static void switchElements(int[,] array1, int[,] array2, int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == j)
                    {
                    }
                    else
                    {
                        int temp = array1[i, j];
                        array1[i, j] = array2[i, j];
                        array2[i, j] = temp;
                    }


                }
            }
            Console.WriteLine("first matrix");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(array1[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine("Second matrix");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(array2[i, j] + " ");
                }
                Console.WriteLine();
            }




        }

        public static int[] getLeftDiagonal(int n, int[,] array1, int[,] array2)
        {
            int index = 0;
            int[] temp = new int[n + n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == j)
                    {
                        temp[index++] = array1[i, j];
                    }
                }
            }



            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == j)
                    {
                        temp[index++] = array2[i, j];
                    }
                }
            }
            //for (int i = 0; i < n + n; i++)
            //{

            //    Console.Write(temp[i] + " ");

            //}
            return temp;





        }


        public static int squareAndAdd(int n, int[,] array1, int[,] array2)
        {
            int[] temp = new int[n + n];
            int index = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i != j && i >= j)
                    {
                        temp[index++] = array1[i, j] * array1[i, j];
                    }
                }
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i != j && i >= j)
                    {
                        temp[index++] = array2[i, j] * array2[i, j];
                    }
                }
            }
            for (int i = 0; i < n + n; i++)
            {

                Console.Write(temp[i] + " ");

            }
            Console.WriteLine();
            int temp2 = new int();

            for (int i = 0; i < n + n; i++)
            {
                temp2 += temp[i];


            }

            return temp2;
        }


    }
}
