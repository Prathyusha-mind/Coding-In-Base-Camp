﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SavingsAccount
{
    class TestMain
    {



        public  SavingsAccount[] withDraw(SavingsAccount[] save,int n)
        {
            for (int i = 0; i < n; i++)
            {
                
                save[i] = new SavingsAccount();
                Console.WriteLine("enter the balance");
                double balance = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("enter the amount you want to withdraw");
                double amount = Convert.ToDouble(Console.ReadLine());
                if (amount > balance)
                {
                    Console.WriteLine("amount is greater than balance!!!!!");
                }
                else
                {
                    Console.WriteLine("Successfully Withdrawn");
                }
            }
            return save;

        }
        public SavingsAccount[] calculateInterest(SavingsAccount save, int n,double balance)
        {
            Console.WriteLine("enter the interest paid");
            int interest_rate = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Simple interest provided for one year is: ");
            int t = 1;

            double SI = (balance * t * interest_rate) / 100;

            Console.WriteLine(SI = (balance * t * interest_rate) / 100);
            return save;
        }

    }
}

