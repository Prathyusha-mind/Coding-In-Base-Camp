﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stackPractice________
{
    class Program
    {
        static void Main(string[] args)
        {

            Queue s = new Queue();
            char c = 'y';
            while (c == 'y')
            {
                Console.WriteLine("enter the stack");
                var ss = Console.ReadLine();
                s.Enqueue(ss);
                Console.WriteLine("do u want to continue Y/N");
                c = Convert.ToChar(Console.ReadLine());
                if (c == 'y')
                {
                    c = 'y';
                }
                else
                {
                    c = 'n';
                }
            }
            Console.WriteLine("------------------");
            foreach(var item in s)
            {
                Console.WriteLine(item);
            }
            s.Dequeue();
            Console.WriteLine("---------------------");
            foreach (var item in s)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
        }
    }
}
