﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capabality1stmarch
{
    class Program
    {

        static void TakeInput(string [,]matrix,int n)
        {
            Console.WriteLine("entre the elements into the matrix");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    matrix[i, j] = Console.ReadLine();
                    if (matrix[i, j].Length > 1)
                    {
                        Console.WriteLine("Cannot take more than one input .......so provide input again");
                        j--;
                    }
                }
            }
            Console.WriteLine("matrix displayed after providing input");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }
        }

        static int[] TDTOD(string [,]matrix,int n)
        {

            Console.WriteLine("matrix displayed after converting to ASCII values");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write((int)matrix[i, j][0] + " ");
                }
                Console.WriteLine();
            }
            int count = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == 0 || j == 0 || i == n - 1 || j == n - 1)
                    {
                       
                        count++;
                    }
                }
            }
            int[] boundaries = new int[count];
            int index = 0;
            Console.WriteLine("boundary elements are:");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == 0 || j == 0 || i == n - 1 || j == n - 1)
                    {
                        boundaries[index++] = (int)matrix[i, j][0];
                    }
                }
            }
          
            return boundaries;
        }
        public static int[] InsertionSort(int[] result)
        {
            int size = result.Length;
            for (int i = 1; i < size; i++)
            {
                int key = result[i];
                int j = i - 1;
                while (j >= 0 && result[j] < key)
                {
                    result[j + 1] = result[j];
                    j = j - 1;
                }
                result[j + 1] = key;

            }
            return result;
        }
        public static int binarySearch(int[] ascArray, int key)
        {
            int low = 0;
            int high = ascArray.Length - 1;
            while (low <= high)
            {
                int mid = (low + high) / 2;
                if (key == ascArray[mid])
                {
                    // Console.WriteLine("element is found at "+mid);
                    return mid;
                }
                else if (key < ascArray[mid])
                {
                    high = mid - 1;
                }
                else
                {
                    low = mid + 1;
                }
            }
            return -1;

        }
        static void Main(string[] args)
        {
            Console.WriteLine("enter the size of matrix");
            int n= Convert.ToInt32(Console.ReadLine());
            string[,] matrix = new string[n, n];
            bool flag = true;
            do
            {
                Console.WriteLine();
                Console.WriteLine("1.display 2D matrix\n");
                Console.WriteLine("2.ASCII value to get all boundary value find insertion sort in descending " +
                    "order and perform binary search on the given 1D array\n");
                Console.WriteLine("3.exit the operation\n");
                Console.WriteLine("enter your choice\n");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        TakeInput(matrix, n);
                        break;
                    case 2:
                        
                        int[] result = TDTOD(matrix, n);
                        for (int i = 0; i < result.Length; i++)
                        {
                            Console.Write(result[i]+" ");
                        }

                        Console.WriteLine();

                       Console.WriteLine("-------Sorted array in descending order-----");
                        int[] sorted = InsertionSort(result);
                        for (int i = 0; i < sorted.Length; i++)
                        {
                            Console.Write(sorted[i]+" ");
                        }


                        Console.WriteLine();
                    
                        int[] ascArray = new int[sorted.Length - 1];
                        int index = 0;
                        for (int i = sorted.Length - 1; i >= 0 && index < ascArray.Length; i--)
                        {
                            ascArray[index] = sorted[i];
                           // Console.WriteLine(sorted[i] + "----" + ascArray[index]);
                            index++;
                        }



                        Console.WriteLine("-------Sorting the elements in Ascending order to perform binary search-----");
                        for (int i = 0; i < ascArray.Length; i++)
                        {
                            Console.Write(ascArray[i]+" ");
                        }


                        Console.WriteLine();

                        Console.WriteLine("Enter a character to search");
                        string input = Console.ReadLine();
                        char c = input[0];

                        int key = (int)c;
                        Console.WriteLine(c + " ---" + key);
                        int position = binarySearch(ascArray, key);
                        if (position >= 0)
                        {
                            Console.WriteLine("Element found at " + position);
                        }
                        else
                        {
                            Console.WriteLine("element not found");
                        }

    
                        break;
                    case 3:
                        flag = false;
                        break;
                    default:
                        Console.WriteLine("invalid input please try again!!!!!!");
                        break;
                }

            } while (flag);

        }
    }
}
