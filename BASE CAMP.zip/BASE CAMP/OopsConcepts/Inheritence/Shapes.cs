﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritence
{
    public class Shapes: Colours
    {
        public void rectangle()
        {
            Console.WriteLine("enter the length");
            int l = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the width");
            int w= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(l*w);

        }
    }
}
