﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CampusMinds
{
    class Program
    {
        static Campus1[] c;
        static void Main(string[] args)
        {
            Console.WriteLine("enter the how many campus minds you want to add ");
            int size = Convert.ToInt32(Console.ReadLine());
            c = new Campus1[size];
            
            bool flag = true;
            do
            {
                Console.WriteLine("1.input the details");
                Console.WriteLine("2.display the details");
                Console.WriteLine("3.sort the campusminds");
                Console.WriteLine("4.Search all the campus minds based on capabalites ");
                Console.WriteLine("5.exit");
                Console.WriteLine("enter your choice");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        insertDetails(c);
                        break;
                    case 2:
                        display(c);
                        break;
                    case 3:
                        sortCampusminds(c);
                        break;
                    case 4:

                        Console.WriteLine("enter the key value");
                        string capabalites = Console.ReadLine();
                       int z= Search(c,capabalites);
                        if (z==-1)
                        {
                            Console.WriteLine("not found");
                        }
                        else
                        {
                            Console.WriteLine(c[z].Mid + " " + c[z].Name + " " + c[z].Capabalites);

                        }
                        
                        break;
                    case 5:
                        flag = false;
                        break;
                    default:
                        break;
                }

            } while (flag);
        }
        public static Campus1[] insertDetails(Campus1[] c)
        {
            for (int i = 0; i < c.Length; i++)
            {
                c[i] = new Campus1();
                Console.WriteLine("give the "+(i+1)+" input");
                Console.WriteLine("enter the mid");
                c[i].Mid= Console.ReadLine();

                Console.WriteLine("enter the campus mind name");
                c[i].Name= Console.ReadLine();

                Console.WriteLine("enter the capabalites");
                c[i].Capabalites= Console.ReadLine();
            }
            return c;

        }
        public static void display(Campus1[] c)
        {
            for (int i = 0; i < c.Length; i++)
            {
                Console.WriteLine(c[i].Mid + " " + c[i].Name + " " + c[i].Capabalites);

            }
        }
        public static void sortCampusminds(Campus1[] c)
        {
            for (int i = 0; i < c.Length - 1; i++)
            {
                for (int j = 0; j < c.Length - i - 1; j++)
                {
                    if (c[j].Mid.CompareTo(c[j + 1].Mid) > 0)
                    {
                        Campus1 temp = c[j];
                        c[j] = c[j + 1];
                        c[j + 1] = temp;
                    }
                }
            }
            for (int i = 0; i < c.Length; i++)
            {
                Console.WriteLine(c[i].Mid + " " + c[i].Name + " " + c[i].Capabalites);
            }
        }
        public static int Search(Campus1[] c,string capabalites  )
        {
            
           for(int i = 0; i <c.Length; i++)
            {
                if (c[i].capabalites==capabalites)
                {
                    return 1;
                }
            }

            return -1;
        }
        public static Campus1[] bubbleSort(Campus1[] c)
        {
            for (int i = 0; i < c.Length - 1; i++)
            {
                for (int j = 0; j < c.Length - i - 1; j++)
                {
                    if (c[j].Capabalites.CompareTo(c[j + 1].Capabalites) > 0)
                    {
                        Campus1 temp = c[j];
                        c[j] = c[j + 1];
                        c[j + 1] = temp;
                    }
                }
            }
            return c;

        }
    }
}
