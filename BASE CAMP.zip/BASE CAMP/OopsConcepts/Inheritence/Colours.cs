﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritence
{
    public  class Colours
    {
        public void Color ()
        {
            Console.WriteLine("RED");
        }
    }
}
