﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SavingsAccount1
{
    class TestMain
    {
        public int account_no;
        public int intrest_rate;
        public double balance;

        public TestMain(int account_no, int intrest_rate, double balance)
        {
            this.account_no = account_no;
            this.intrest_rate = intrest_rate;
            this.balance = balance;
        }
        public TestMain()
        {

        }
    }
}
