﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SavingsAccount
{
    class SavingsAccount
    {
        public int account_no;
        public int intrest_rate;
        public double balance;

        public SavingsAccount(int account_no, int intrest_rate, double balance)
        {
            this.account_no = account_no;
            this.intrest_rate = intrest_rate;
            this.balance = balance;
        }
        public SavingsAccount()
        {

        }


        static void Main(string[] args)
        {

            Console.WriteLine("enter the number of inputs to be given");
            int n= Convert.ToInt32(Console.ReadLine());
            SavingsAccount[] s = new SavingsAccount[n];
           
         

            Console.ReadKey();
        }
    }
}
