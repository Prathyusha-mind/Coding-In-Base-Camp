﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Savings
{
    class Program
    {
        public int account_no;
        public int intrest_rate;
        public double balance;

        public Program(int account_no, int intrest_rate, double balance)
        {
            this.account_no = account_no;
            this.intrest_rate = intrest_rate;
            this.balance = balance;
        }
        public Program()
        {

        }
        public static void withDraw(double amount,double balance)
        {
            
            if (amount > balance)
            {
                Console.WriteLine("amount is greater than balance!!!!!");
            }
            else
            {
                Console.WriteLine("Successfully Withdrawn");
            }
        }
        public static void calculateInterest(int interest_rate,double balance)
        {
            int t = 1;
            double SI = (balance * t * interest_rate) / 100;
            
            Console.WriteLine(SI = (balance * t * interest_rate) / 100);
        }
        static void Main(string[] args)
        {

            Console.WriteLine("enter the account number");
            int account_no = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the interest rate");
            int interest_rate = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the balance");
            double balance = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("enter the amount you want to withdraw");
            double amount = Convert.ToDouble(Console.ReadLine());
            withDraw(amount,balance);


            Console.WriteLine("Interest calculated for a year");
            calculateInterest(interest_rate,balance);
            Console.ReadKey();
        }
    }
}
