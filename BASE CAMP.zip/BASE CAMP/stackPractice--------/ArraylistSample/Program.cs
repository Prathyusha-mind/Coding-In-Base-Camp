﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraylistSample
{
    class Program
    {
        int Id;
        string Name;
        string Location;
        public Program()
        {

        }
        public Program(int Id,string Name,string Location)
        {
            this.Id = Id;
            this.Name = Name;
            this.Location = Location;
        }
        static void Main(string[] args)
        {
            ArrayList a = new ArrayList();
            a.Add("qwe");
            a.Add("12");
            foreach(var i in a)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("=-------------------");
            for(int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i]);
            }

            Program p1 = new Program()
            {
                Id = 10,
                Name="hima",
                Location="Goa"
               
            };
            Program p2 = new Program()
            {
                Id = 20,
                Name = "hemalatha",
                Location = "Goadrytg"

            };
            Dictionary<int, Program> dict = new Dictionary<int, Program>();
            dict.Add(p1.Id, p1);
            dict.Add(p2.Id, p2);
            Console.WriteLine("---------------Dictonary-----------------------------");
            foreach(KeyValuePair<int,Program> x in dict)
            {
                Console.WriteLine("id:{0}",x.Key);
                Program p = x.Value;
                Console.WriteLine("id:{0},Name:{1},Location:{2}",p.Id,p.Name,p.Location);
                Console.WriteLine("......................................................");
            }
            foreach(int key in dict.Keys)
            {
                Console.WriteLine(key);
            }
            foreach(var val in dict.Values)
            {
                Console.WriteLine("id:{0},Name:{1},Location:{2}",val.Id,val.Name,val.Location);
            }
            HashSet<string> hash = new HashSet<string>();
            hash.Add("hi");
            hash.Add("hi");
            hash.Add("abc");
            hash.Add("good morning");
            Console.WriteLine("---------------hash-----------------------");
            foreach(string x in hash)
            {
                Console.WriteLine(x);
            }
            SortedSet<int> sort = new SortedSet<int>();
            sort.Add(23);
            sort.Add(9887);
            sort.Add(1);
            Console.WriteLine("-----------------Sort-------------------");
            foreach(int y in sort)
            {
                Console.WriteLine(y);
            }
            LinkedList<string> s = new LinkedList<string>();
            s.AddLast("Prathyusha");
            s.AddFirst("hello");
            Console.WriteLine("---------------linked list----------------");
            foreach(string x in s)
            {
                Console.WriteLine(x);
            }
            //s.AddBefore(s, "hi");
            Console.ReadKey();
        }
    }
}
