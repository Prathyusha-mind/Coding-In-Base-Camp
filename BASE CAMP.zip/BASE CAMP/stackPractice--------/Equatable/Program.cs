﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equatable
{
    class Program:IEquatable<Program>
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool Equals(Program other)
        {
            return ((FirstName == other.FirstName) && (LastName == other.LastName));
        }
        static void Main(string[] args)
        {
            List<Program> ps = new List<Program>();
            Program p = new Program()
            {
                FirstName = "hima",
                LastName = "hima"
            };
            if (ps.Contains(p))
            {
                Console.WriteLine("present");
            }
            else
            {
                Console.WriteLine("not match");
            }
            Console.ReadKey();
        }

       
    }
}
