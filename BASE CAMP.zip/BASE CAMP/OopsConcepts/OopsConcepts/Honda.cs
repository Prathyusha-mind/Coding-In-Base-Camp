﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsConcepts
{
    class Honda:Car

    {
        Honda h = new Honda();
        void display()
        {
            Console.WriteLine(price);
            Console.WriteLine(h.colour);
            Console.WriteLine(h.seats);
            Console.WriteLine(h.tax);


        }
    }
}
