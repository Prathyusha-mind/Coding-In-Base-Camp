﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringProblem
{
    class Program
    {
        public static void Sort(string str)
        {
            char[] arr1 = new char[str.Length];
            char ch;
            for(int i = 0; i < str.Length; i++)
            {
                arr1[i] = str[i];
            }


            for (int i = 1; i < str.Length; i++)
            {
                for (int j = 0; j < str.Length - i; j++)
                {
                    if (arr1[j] > arr1[j + 1])
                    {
                        ch = arr1[j];
                        arr1[j] = arr1[j + 1];
                        arr1[j + 1] = ch;
                    }
                }
            }
            int count = 1;

            for(int i=0;i<arr1.Length-1;i++)
            {
                if (arr1[i] == arr1[i + 1])
                {
                    count++;
                }
                else
                {
                    if (count > 1)
                    {
                        Console.Write(arr1[i]);
                        Console.WriteLine(" " + count);
                    }

                    count = 1;
                }

            }
            if (count > 1)
            {
                Console.Write(arr1[arr1.Length - 1]);
                Console.WriteLine(" " + count);
            }
          
         }
        static void Main(string[] args)
        {
            Console.WriteLine("enter the string");
            string str = Console.ReadLine();
            Sort(str);
            Console.ReadLine();
        }
    }
}
