﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Softwares
{
    class Software
    {
        public int id;
        public int licensenumber;
        public string name;
        public double cost;
        public Software()
        {
        }
            public Software(int id, int licensenumber, string name, double cost)
        {
            this.id = id;
            this.licensenumber = licensenumber;
            this.name = name;
            this.cost = cost;
        }

        public int Id { get; set; }
        public int LicenseNumber { get; set; }
        public string Name { get; set; }
        public int Cost { get; set; }
    }
}
