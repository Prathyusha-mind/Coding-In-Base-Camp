﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capabality4
{
    class Hospital
    {
        //private int doctorId;
        //private string doctorName;
        //private int salary;

        //public Hospital(int doctorId, string doctorName, int salary)
        //{
        //    this.doctorId = doctorId;
        //    this.doctorName = doctorName;
        //    this.salary = salary;
        //}
        //public Hospital()
        //{

        //}
        public int DoctorId { get; set; }
        public string DoctorName { get; set; }
        public int Salary { get; set; }
    }
}
