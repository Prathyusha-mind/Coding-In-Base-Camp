﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CampusMinds
{
    class Campus1
    {
        
            public string mid;
            public string name;
            public string capabalites;

            public Campus1()
            {

            }
            public Campus1(string mid, string name, string capabalites)
            {
                this.mid = mid;
                this.name = name;
                this.capabalites = capabalites;
            }

            public string Mid { get; set; }
            public string Name { get; set; }
            public string Capabalites { get; set; }
        
    }
}
