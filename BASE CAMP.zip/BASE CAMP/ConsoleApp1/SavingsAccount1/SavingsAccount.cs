﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SavingsAccount1
{
    class SavingsAccount
    {
        static int account_no, intrest_rate;
        static double balance;
        static TestMain[] test;
        static void Main(string[] args)
        {
            Console.WriteLine("enter the number of inputs to be given");
            int n = Convert.ToInt32(Console.ReadLine());
            test = new TestMain[n];
            withDraw(amount, n);

        }
        public static void withDraw(double amount,int n)
        {
            for(int i = 0; i < n; i++)
            {
                Console.WriteLine("enter the account number");
                int account_no = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter the amount you want to withdraw");
                amount = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("enter the balance");
                double balance = Convert.ToDouble(Console.ReadLine());
                
                if (amount > balance)
                {
                    Console.WriteLine("amount is greater than balance!!!!!");
                }
                else
                {
                    Console.WriteLine("Successfully Withdrawn");
                }
               // TestMain[i] = new TestMain(account_no, intrest_rate, balance);

            }
        }
        public static void SimpleIntrest(int n)
        {
            for(int i = 0; i < n; i++)
            {
                Console.WriteLine("enter the interest paid");
                int interest_rate = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Simple interest provided for one year is: ");
                int t = 1;

                double SI = (balance * t * interest_rate) / 100;

                Console.WriteLine(SI = (balance * t * interest_rate) / 100);

            }
        }
    }
}
