﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Softwares
{
    class Program
    {
        
        static void Main(string[] args)
        {
             Software[] s;
            Console.WriteLine("enter how many inputs you want to give");
            int n = Convert.ToInt32(Console.ReadLine());
            s = new Software[n];

            bool flag = true;
            do
            {
                Console.WriteLine("1.Insert");
                Console.WriteLine("2.display");
                Console.WriteLine("3.Purchase software sorted based on cost and show bill after adding 5% gst ");
                Console.WriteLine("4.binary search to find particular software based on id");
                Console.WriteLine("5.exit");
                Console.WriteLine("enter your choice");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        s=Insert(s,n);
                        break;
                    case 2:
                        Display(s);
                        break;
                    case 3:
                        Software[] y =insertionSortByCost(s);//sort based on cost
                        Console.WriteLine();
                        Console.WriteLine("enter the cost u want to search and get bill\n");
                        int k = Convert.ToInt32(Console.ReadLine());
                        int p1 = binarySearch(y, k);
                        Console.WriteLine("*****************************BILL**************************\n");
                        if (p1 >= 0)
                        {
                            Console.WriteLine("Id of the software::"+y[p1].Id + "    "+"cost::"+(y[p1].Cost + (5*y[p1].Cost)/100));
                        }
                        else
                        {
                            Console.WriteLine("not found");
                        }

                        break;
                    case 4:
                        Software[] x= insertionSorttoselect(s);
                       
                        Console.WriteLine("enter the id you want to search");
                        int key= Convert.ToInt32(Console.ReadLine());
                        int p=binarySearch(x, key);
                        if (p >= 0)
                        {
                            Console.WriteLine(x[p].Id + "  " + x[p].LicenseNumber + "   " + x[p].Name + "    " + x[p].Cost);
                        }
                        else
                        {
                            Console.WriteLine("not found");
                        }
                        break;
                    case 5:flag = false;

                        break;
                   default:
                        break;
                }
            } while (flag);
        }
        public static Software[] Insert(Software[] s,int n)
        {
         
            for (int i = 0; i < n; i++)
            {
                s[i] = new Software();
                Console.WriteLine("enter the id");
                s[i].Id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter the licence no");
                s[i].LicenseNumber= Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("entre the name");
                s[i].Name = Console.ReadLine();
                Console.WriteLine("enter the cost");
                s[i].Cost= Convert.ToInt32(Console.ReadLine());

            }
            return s;
        }
        public static void Display(Software[] s)
        {
            for(int i = 0; i <s.Length; i++)
            {
                
                Console.WriteLine(s[i].Id+"  "+s[i].LicenseNumber+"   "+s[i].Name+"    "+s[i].Cost);

            }
           
        }
        //public static void Sort(Software[] s)
        //{
        //    for(int i = 0; i < s.Length-1; i++)
        //    {
        //        for(int j = 0; j < s.Length-1-i; j++)
        //        {
        //            if (s[j].Cost >= s[j + 1].Cost)
        //            {
        //                Software temp = s[j];
        //                s[j + 1] = s[j];
        //                s[j] = temp;
        //            }
        //        }
        //    }
        //    for(int i = 0; i < s.Length; i++)
        //    {
        //        Console.WriteLine(s[i].Id + " " + s[i].LicenseNumber +  "  " + s[i].Name + "  " +s[i].Cost);
        //    }
        //}
        public static Software[] insertionSortByCost(Software[] s1)//sort based on cost
        {
         for(int i = 1; i < s1.Length ; i++)
            {
                int cost = s1[i].Cost;
                //int Key = s[i].Cost;
                Software key = s1[i];
                int j=i-1;
                while(j>=0&&s1[j].Cost > cost)
                {
                    
                   
                        s1[j + 1] = s1[j];
                        j = j - 1;
                    
                }
                
                s1[j + 1] = key;
            }
            for (int i = 0; i < s1.Length; i++)
            {

                Console.WriteLine(s1[i].Id + "  " + s1[i].LicenseNumber + "   " + s1[i].Name + "    " + s1[i].Cost);

            }

            return s1;
        }
        public static Software[] insertionSorttoselect(Software[] s1)//sort based on id
        {
            for (int i = 1; i < s1.Length ; i++)
            {
                Software Key = s1[i];
                int Id = s1[i].id;
                int j;
                for (j = i - 1; j >= 0 && s1[j].Id < Id; j--)
                {
                    s1[j + 1] = s1[j];
                }
                s1[j + 1] = Key;
            }
            for (int i = 0; i < s1.Length; i++)
            {

                Console.WriteLine(s1[i].Id + "  " + s1[i].LicenseNumber + "   " + s1[i].Name + "    " + s1[i].Cost);

            }
            return s1;
        }
        public static int binarySearch(Software[] s,int key)//search based on id
        {
            insertionSorttoselect(s);
            int low = 0;
            int high = s.Length - 1;
            while (low <= high)
            {
                int mid = (low + high) / 2;
                if (key ==s[mid].Id)
                {
                    
                    return mid;
                }
                else if (key < s[mid].Id)
                {
                    high = mid - 1;
                }
                else
                {
                    low = mid + 1;
                }
            }
            return -1;


        }
       
    }
}
