﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringReverse
{
    class Program
    {
        static string Reverse(string s)
        {
            string s1 = " ";
            for(int i=s.Length - 1; i >= 0; i--)
            {
                if(s==" ")
                {
                    
                }
                s1 = s1 + s[i];
            }
            
            return s1;
        }
        static void Pattern(int n)
        {
            for(int i = 0; i < n; i++)
            {
                for(int j =0; j < i; j++)
                {
                    Console.Write(" "+"*");
                }
                Console.WriteLine();
            }
            

        }
        static void Main(string[] args)
        {
            Console.WriteLine("enter the string");
            int n = int.Parse(Console.ReadLine());
            // string s = Console.ReadLine();
            /*string x=Reverse(s);
            if(x==" ")
            {
            Console.WriteLine(x);

            }*/
         Pattern(n);
      
            Console.ReadKey();
        }
    }
}
