﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo
{
    class Program
    {
        public static string  Sort(string str)
        {
            char[] arr1 = new char[str.Length];
            char ch;
            for (int i = 0; i < str.Length; i++)
            {
                arr1[i] = str[i];
            }


            for (int i = 0; i < str.Length-1; i++)
            {
                for (int j = 0; j < str.Length - i-1; j++)
                {
                    if (arr1[j] > arr1[j + 1])
                    {
                        ch = arr1[j];
                        arr1[j] = arr1[j + 1];
                        arr1[j + 1] = ch;
                    }
                }
            }

            string temp = "";
            for (int i = 0; i < str.Length; i++)
            {
                temp = temp + arr1[i];
            }
            return temp;

        }
      

        public static void separation(string s)
        {
            
            string temp = "";
            string temp1 = "";
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] >= 'A'|| s[i] <= 'Z')
                {
                    temp = temp + s[i];
                   temp= Sort(temp);
                }
                else
                {
                    temp1 = temp1 + s[i];
                   temp1= Sort(temp1);
                   
                }
               
            }
            Console.WriteLine(temp);
            Console.WriteLine(temp1);
            Console.WriteLine(temp + temp1);


        }
     
        public static void repeated(int[] array, int n)
        {
            int count = 1;
            for(int i = 0; i < n-1; i++)
            {
                if (array[i] == array[i + 1])
                {
                    count++;
                }
                else
                {
                    if (count == 1)
                    {
                        Console.WriteLine(array[i] + "=" + count);
                    }
                    count = 1;

                }
            }
            if (count == 1)
            {
                Console.WriteLine(array[array.Length - 1] + "=" + count);
            }
            
        }
        static void Main(string[] args)
        {
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1.1D");
                Console.WriteLine("2.String");
                Console.WriteLine("enter your chice");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("enter the array size");
                        int n = Convert.ToInt32(Console.ReadLine());
                        int[] array = new int[n];
                        Console.WriteLine("enter the array");
                        for (int i = 0; i < n; i++)
                        {
                            array[i] = Convert.ToInt32(Console.ReadLine());
                        }
                       repeated(array,n);
                        Console.ReadKey();
                      break;



                        case 2:


                        Console.WriteLine("enter the string");
                        string s = Console.ReadLine();
                        separation(s);
                        


                        break;
                    case 3:flag = false;
                        break;
                    default:
                        break;

                }
            }
            Console.ReadKey();
            
        }
    }
}
