﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueuePractice
{
    class Program
    {
        static void Main(string[] args)
        {

            Queue q = new Queue();
            char c = 'y';
            while (c=='y')
            {
                Console.WriteLine("Eneter the elemnet");
                var x = Console.ReadLine();
                q.Enqueue(x);
                Console.WriteLine("do you want to enter");
                c = Convert.ToChar(Console.ReadLine());
                if (c == 'y')
                {
                    c = 'y';
                }
                else
                {
                    c = 'n';
                }
            }
            foreach(var i in q)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
