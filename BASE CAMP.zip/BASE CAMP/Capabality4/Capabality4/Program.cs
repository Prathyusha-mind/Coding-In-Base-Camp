﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capabality4
{
    class Program
    {
        static Hospital[] h;
        static void Main(string[] args)
        {
            Console.WriteLine("enter number of inputs u want to give");
            int n = Convert.ToInt32(Console.ReadLine());
            h = new Hospital[n];
            bool flag = true;
            do
            {
                Console.WriteLine("1.Insert 5 doctor");
                Console.WriteLine("2.Ask user to enter doctorId and display the doctor details based on binary search.");
                Console.WriteLine("3.Sort the doctors based on salary. ");
                Console.WriteLine("4.Display all doctor details whose name starts with ‘a’.");
                Console.WriteLine("enter your choice");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        insert(h);
                        break;
                    case 2:
                        Console.WriteLine("enter the doctor id");
                        int key = Convert.ToInt32(Console.ReadLine());

                        int p = BinarySearch(h, key);
                        if (p >= 0)
                        {
                            Console.WriteLine(h[p].DoctorId + " " + h[p].DoctorName + "  " + h[p].Salary);
                        }
                        else
                        {
                            Console.WriteLine("doctor not found");
                        }
                        break;
                    case 3:
                        BubbleSort(h);
                        break;
                    case 4:
                        Start(h);
                        break;
                    case 5:flag = false;
                        break;
                    default:
                        break;
                }

            } while (flag);
        }
        public static Hospital[] insert(Hospital[] h)
        {
            
            for(int i = 0; i <h.Length; i++)
            {
                h[i] = new Hospital();
                Console.WriteLine("enter the doctor id");
                h[i].DoctorId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("entre the doctor name");
                h[i].DoctorName = Console.ReadLine();
                Console.WriteLine("enter the doctor salary");
                h[i].Salary= Convert.ToInt32(Console.ReadLine());

            }
            return h;

        }
        public static void BubbleSort(Hospital[] h)
        {
            for(int i = 0; i < h.Length-1; i++)
            {
                for(int j = 0; j < h.Length - 1 - i; j++)
                {
                    if (h[j].Salary >= h[j + 1].Salary)
                    {
                        Hospital temp = h[j];
                        h[j]= h[j + 1];
                        h[j + 1] = temp;
                    }
                }
            }
            for(int i = 0; i < h.Length; i++)
            {
                Console.WriteLine(h[i].DoctorId+" "+h[i].DoctorName+"  "+h[i].Salary);
            }
        }
        public static void Start(Hospital[] h)
        {
            string temp = "";
            
            for(int i = 0; i < h.Length - 1; i++)
            {
                temp = h[i].DoctorName;
                if (temp[0]=='a')
                {
                    Console.WriteLine(h[i].DoctorId + " " + h[i].DoctorName + "  " + h[i].Salary);
                }
              
            }
        }
        public static Hospital[]  BubbleSortOnId(Hospital[] h)
        {
            for (int i = 0; i < h.Length - 1; i++)
            {
                for (int j = 0; j < h.Length - 1 - i; j++)
                {
                    if (h[j].DoctorId >= h[j + 1].DoctorId)
                    {
                        int temp = h[j].DoctorId;
                        h[j].DoctorId= h[j + 1].DoctorId;
                        h[j + 1].DoctorId = temp;
                    }
                }
            }
            return h;
        }
        public static int BinarySearch(Hospital[] h,int key)
        {
            BubbleSortOnId(h);
            int low = 0;
            int high = h.Length- 1;
            
            while (low <= high)
            {
                int mid = (low + high) / 2;
                if(key==h[mid].DoctorId)
                {
                   return mid;
                }
                else if(key<h[mid].DoctorId)
                {
                    high = mid - 1;
                }
                else
                {
                    low = mid + 1;
                }
                
              
            }
            return -1;
           


        }




    }





}
