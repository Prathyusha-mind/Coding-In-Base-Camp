﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Program
    {
        public static void sort(int []matrix)
        {

        }
        public static void TwoDToOneD(int [,]matrix1,int [,]matrix2,int n)
        {
            int count = 0;
            int[] temp = new int[n*n];
            for(int i = 0; i < n; i++)
            {
                for(int j = 0; j < n; j++)
                {
                    temp[count++] = matrix1[i, j];
                }
            }
            for(int j = 0; j < count; j++)
            {
                Console.Write(temp[j]+" ");
            }
            Console.WriteLine();


            Console.WriteLine("second 1D matrix is\n ");
            int count1 = 0;
            int[] temp1 = new int[n * n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    temp1[count1++] = matrix2[i, j];
                }
            }
            for (int j = 0; j < count1; j++)
            {
                Console.Write(temp1[j] + " ");
            }
            Console.WriteLine();
           // int[] temp2=new int[2*(n*n)];
            //int count2 = 0;
            int[] result = new int[2*(n * n)];
            int i, j;
            for ( i = 0, j= 0; i < 2 * (n * n); i++)
            {
                result[j++] = temp[i];
            }
            for (i = 0; i < 2 * (n * n); i++)
            {
                result[j++] = temp1[i];
            }
            Console.WriteLine(result[j]);

        }
    
        static void Main(string[] args)
        {

            Console.WriteLine("enter the size of the array");
            int n= Convert.ToInt32(Console.ReadLine());
            int[,] matrix1 = new int[n, n];
            int[,] matrix2 = new int[n, n];

            Console.WriteLine("enter the first matrix");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++) {

                    matrix1[i,j]= Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("enter the second matrix");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {

                    matrix2[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1.Converting 2D to 1D and then sort\n");
                Console.WriteLine("2.even index element to be printed");
                Console.WriteLine("3.Binary search operation");
                Console.WriteLine("4.exit");
                Console.WriteLine("enter your choice");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        TwoDToOneD(matrix1, matrix2, n);
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    case 4:flag = false;
                        break;
                    default:
                        Console.WriteLine("invalid input");
                        break;
                }

            }
        }
    }
}
