﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capabality2_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the string");
            string s = Console.ReadLine();
           
            string temp="";
        
            
            for (int i=0;i<s.Length;i++ )
            {
                
                if (s[i] >= 'A' && s[i] <= 'Z')
                {
                    
                    temp= temp+ (char)(s[i] +32);

                    
                }
                else
                {
                    temp = temp +s[i];
                }


            }
            //Console.Write(temp);
            Console.WriteLine();
            int count = 1;
            for (int i = 0; i < temp.Length - 1; i++)
            {
                if (temp[i] == temp[i + 1])
                {
                    count++;
                }
                else
                {
                    Console.Write(temp[i]);
                    if (count > 1)
                    {
                        
                        Console.Write(count);
                    }
                    count = 1;
                }
            }
            Console.Write(temp[temp.Length - 1]);
            if (count > 1)
            {
                
                Console.Write(count);
            }
            
            Console.ReadKey();
        }
    }
}
