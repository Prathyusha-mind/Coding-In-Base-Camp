﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsConcepts
{
    class Car
    {
        public double price;
        public string colour;
        public int seats;
        public double tax;

        public Car(double price, string colour, int seats, double tax)
        {
            this.Price = price;
            this.Colour = colour;
            this.Seats = seats;
            this.Tax = tax;
        }

        public Car()
        {

        }
        public double Price { get => price; set => price = value; }
        public string Colour { get => colour; set => colour = value; }
        public int Seats { get => seats; set => seats = value; }
        public double Tax { get => tax; set => tax = value; }
    }
}
