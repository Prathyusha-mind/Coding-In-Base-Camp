﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VowelMatrix
{
    class Program
    {   static char Print(char[] s,int n)
        {
            for(int i = 0; i < n; i++)
            {
                for(int j = 0; j < n; j++)
                {
                     Console.WriteLine(s[i, j]);
                }
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("enter the matrix size");
            int n = Convert.ToChar(Console.ReadLine());
            char[,] s = new char[n, n];
            for(int i=0; i < n; i++)
            {
                for(int j = 0; j < n; j++)
                {
                    s[i,j]=Console.ReadLine();
                }
            }


        }
    }
}
